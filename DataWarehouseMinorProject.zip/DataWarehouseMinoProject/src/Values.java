/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author aatish
 */
public class Values {
    public static String database_name="dw_minor";
    public static String username="SA";
    public static String password="Aatish989130@";
    public static String decisionsString;
    public static String uncertaintysString;
    public static String actionsString;
    public static String objectiveString;   
    public static String imperative;   
    public static int u;
    public static int a;
    public static int o;    
}
